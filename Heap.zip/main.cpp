// Heap program by Siddhartha Bobba
//April 31, 2021

//A heap program to make a binary tree where every node is larger than it's child


#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
#include <cmath>

using namespace std;

//functions

void printHeap(int* heap, int size);
void removeHeap(int* heap, int size);

void parse(char* in, int* mod, int &count);

void createHeap(int* mod, int* heap, int size);
int getMax(int* arr);


int main() {

  char filename[30]; //variable to get the file name
  char input[1000]; //variable to get the input
  
  char initinp[10]; 
  int charcount = 0; //to count the number of characters
  int mod[100];
  
  bool run = true;
  while(run) {

  for (int i = 0; i < 100; i++) { //to clear the integer array

    mod[i] = 0;
  }

  //main

  cout << "This is a program for Heap." << endl;
  cout << "You have two commands: 'HEAP', 'QUIT'. " << endl;
  
  cin.get(initinp, 10); //gets the user's input for heap or quit
  cin.clear();
  cin.ignore(10000, '\n'); //terminating character

  if (initinp[0] == 'H' && initinp[1] == 'E' && initinp[2] == 'A' && initinp[3] == 'P') {
    
    cout << "Would you like to type in your input or feed in a file?" << endl;
    cout << "You have two commands: 'FILE', 'TYPE'. " << endl;
    
    cin.get(initinp, 10);
    cin.clear();
    cin.ignore(10000, '\n');
    
    if (initinp[0] == 'F' && initinp[1] == 'I' && initinp[2] == 'L' && initinp[3] == 'E') {

      cout << "What is the name of the file?" << endl << "ENTER THE NAME OF THE FILE:";
      cout << endl;
      
      cin.get(filename, 30);
      cin.clear();
      cin.ignore(10000, '\n'); //terminating character
      
      //getting the file
      streampos size;  //stream position
      ifstream file(filename, ios::in | ios::binary | ios::ate);
      
      //finish file stuff

       if (file.is_open()) {

	size = file.tellg();
	file.seekg(0, ios_base::beg); //beginning of stream
	file.read(input, size); //read the content and the size of the file
	file.close(); //close the file

	parse(input, mod, charcount); //enters the input into the modified array

	cout << "In: ";

	for (int i = 0; i < 100; i++) {

	  if (mod[i] == 0) break;
	  cout << mod[i] << " "; //couts the inputs from file

	}
	cout << endl;
	
      }
    }
    else if (initinp[0] == 'T' && initinp[1] == 'Y' && initinp[2] == 'P' && initinp[3] == 'E') {
      
      cout << "Type in numbers, seperated by a space:" << endl;
      char in[10000];
      
      cin.get(in, 10000);
      cin.clear();
      cin.ignore(10000, '\n');
      
      parse(in, mod, charcount);
      cout << "IN: ";
      for (int i = 0; i < 100; i++) {
	
	if(mod[i] == 0) break; //????
	cout << mod[i] << " "; //????
      }
      cout << endl;
    }
    else {
      
      cout << "Invalid Input. Please enter the correct command." << endl; 
    }
    
    //create a heap tree here || linear

    int heap[102];
    
    for (int c = 0; c < 101; c++) {
      heap[c] = 0;  //clear
    }

    //get size of modified array
    int sizee = 0;

    for (int i = 0; i < 100; i++) {
      if(mod[i] != 0) {
	sizee++;
      } 
      else break; //else end
    }
    
    createHeap(mod, heap, sizee);

    cout << "Heap has been constructed" << endl;
    
    for (int i = 1; i < 101; i++) {
      if (heap[i] == 0) break; // if condition, break
      
      cout << heap[i] << " ";
    }
    
    cout << endl; //space
    
    printHeap(heap, sizee);
    cout << "Deleting HEAP" << endl;
    removeHeap(heap, sizee);
    
  }
  else if (initinp[0] == 'Q' && initinp[1] == 'U' && initinp[2] == 'I' && initinp[3] == 'T') {

    cout << endl << "GOODBYE!" << endl;
    run = false;

  }
  else {
    
    cout << endl << "Invalid input. You can try again." << endl;

  }
}

} 
//}
//Thanks to Bradley for the help
void createHeap(int* mod, int* heap, int size) {
  int current = 1;
  
  //set index at 1 to largest int
  heap[1] = mod[getMax(mod)];  //largest set at index 1
  mod[getMax(mod)] = 0;
  
  while(current <= size) {
    
    //check if out of nums
    if(heap[2*current] == 0) {  //if right child is empty
      //fill right child with the next max integer
      
      heap[2*current] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
      
      //fill left child with the next max integer
      heap[2*current+1] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
    } 
    else {  //if right child is not empty
      //fill left child with next max int
      heap[2*current+1] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
    }
    current++;
  }
}

int getMax(int* arr) {
  int i;
  
  for (int l = 0; l < 100; l++) {
    
    if (arr[l] >= arr[i]) {
      i = l;
    }
    
  }
  
  return i;
}

void printHeap(int* heap, int size) {
  
  for(int i = 1; i <= size/2; i++) {
    
    if(heap[i] != 0) {
      cout << endl << "Root=" << heap[i] << " "; //heap
    }
    
    if (heap[i * 2] != 0) {
      cout << "L=" << heap[i*2] << " "; //int i*2 
    }
    
    if(heap[i * 2 + 1] != 0) {
      cout << "R=" << heap[i*2+1] << endl; //int i*2 plus 1
    }
    
  }
}

void removeHeap(int* heap, int size) { //to delete the heap
  
  for (int i = 1; i <= size; i++) {
    cout << heap[i] << " "; //empty
    heap[i] = 0; //sets heap to 0
  }
  
  cout << endl; //skip line
}

void buildHeap(int* mod, int* heap, int size) {
  int current = 1;
  //set index at pos 1 to largest integer
  heap[1] = mod[getMax(mod)];  //index one - largest
  mod[getMax(mod)] = 0;
  while(current <= size) { //when out of integers
    
    
    if(heap[2*current] == 0) {  //if right child = empty
      
      //fill right child with next max int
      heap[2*current] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
      
      //now fill left chile with next
      heap[2*current+1] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
    }
    
    else {  //if right child filled
      
      //fill left child with next max int
      heap[2*current+1] = mod[getMax(mod)];
      mod[getMax(mod)] = 0;
      
    }
    
    current++;
  }
}


void parse(char* in, int* mod, int &count) {
  
  int l = 0;  //keeps track of # of chars before space

  for (int i = 0; i < strlen(in); i++) {

    if (in[i] == ' ') {
      if (l == 1) {

	int temp = 0;

	temp = in[i-1] - '0';
	mod[count] = temp;

	count++;
	l = 0;
	
      }
      else {

	int temp = 0;

	for (int a = 0; a < l; a++) {
	  temp = 10 * temp + (in[i-l+a] - '0');
	}

	mod[count] = temp;

	count++;
	l = 0;
      }
    }
    else {

      int temp = 0;
      l++;

      if (i == strlen(in) - 1) {  //last
	for (int a = 0; a < l; a++) {

	  temp = 10 * temp + (in[i+a+1-l] - '0');
	}
	mod[count] = temp;

	count++;
      }
    }
  }  
}
